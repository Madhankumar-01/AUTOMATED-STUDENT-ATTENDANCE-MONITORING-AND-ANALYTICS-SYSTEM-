# Automated Student Attendance Monitoring and Analytics System

A web-based system to record student attendance and analyze attendance trends,
built with Flask and SQLite.

## Features
- Admin/teacher login
- Add courses and students
- Mark daily attendance (Present/Absent)
- Attendance analytics: per-student percentage, defaulter list (<75%)

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Visit `http://127.0.0.1:5000` in your browser.

Default login: `admin` / `admin123`

## Project Structure
```
attendance-system/
├── app.py                  # Main Flask app: routes, DB logic
├── requirements.txt
├── database/
│   └── attendance.db       # SQLite DB (auto-created on first run)
├── templates/
│   ├── base.html
│   ├── login.html
│   ├── dashboard.html
│   ├── students.html
│   ├── courses.html
│   ├── mark_attendance.html
│   └── reports.html
└── static/
    └── css/style.css
```

## Notes
- Change `app.secret_key` in `app.py` before deploying.
- This is a starter project intended to be extended (e.g., QR/face-recognition
  based attendance capture, role-based access for teachers vs admins).
